package com.strv.academyarchitecture.view;


public interface MainView extends BaseView
{
	void onClick();
}
