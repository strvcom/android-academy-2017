package com.strv.academyplayground.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.strv.academyplayground.R;


public class MainFragment extends Fragment
{
	public MainFragment()
	{
	}


	public static MainFragment newInstance()
	{
		return new MainFragment();
	}


	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		return inflater.inflate(R.layout.fragment_main, container, false);
	}


	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState)
	{
		super.onActivityCreated(savedInstanceState);

		TextView textview1 = (TextView) getView().findViewById(R.id.fragment_main_text1);
		TextView textview2 = (TextView) getView().findViewById(R.id.fragment_main_text2);

		Toast.makeText(getActivity(), textview1.getText(), Toast.LENGTH_SHORT).show();

	}
}
