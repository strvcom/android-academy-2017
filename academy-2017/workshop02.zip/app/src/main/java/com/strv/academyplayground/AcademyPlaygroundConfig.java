package com.strv.academyplayground;


public class AcademyPlaygroundConfig
{
	public static final boolean LOGS = BuildConfig.LOGS;
	public static final boolean DEV_ENVIRONMENT = BuildConfig.DEV_ENVIRONMENT;

	public static final String REST_BASE_URL_PROD = "http://example.com/api/";
	public static final String REST_BASE_URL_DEV = "http://dev.example.com/api/";
	public static final String REST_BASE_URL = DEV_ENVIRONMENT ? REST_BASE_URL_DEV : REST_BASE_URL_PROD;
}
