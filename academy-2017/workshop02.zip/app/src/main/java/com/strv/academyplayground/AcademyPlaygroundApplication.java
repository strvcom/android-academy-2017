package com.strv.academyplayground;

import android.app.Application;
import android.content.Context;


public class AcademyPlaygroundApplication extends Application
{
	private static AcademyPlaygroundApplication sInstance;


	public AcademyPlaygroundApplication()
	{
		sInstance = this;
	}


	public static Context getContext()
	{
		return sInstance;
	}


	@Override
	public void onCreate()
	{
		super.onCreate();
		// TODO
	}
}
