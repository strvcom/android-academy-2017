package com.strv.academyplayground.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.strv.academyplayground.AcademyPlaygroundApplication;
import com.strv.academyplayground.R;


public class MainActivity extends AppCompatActivity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Log.d("ACADEMY", "Hello world");

		Toast.makeText(getApplicationContext(), "Hello Academy", Toast.LENGTH_LONG).show();

		Context appContext = getApplicationContext();
		Context appContext2 = AcademyPlaygroundApplication.getContext();
		Context activityContext = this;


		activityContext.getApplicationContext();


	}
}
