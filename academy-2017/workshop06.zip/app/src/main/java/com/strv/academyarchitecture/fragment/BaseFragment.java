package com.strv.academyarchitecture.fragment;

import android.databinding.ViewDataBinding;
import android.widget.Toast;

import com.strv.academyarchitecture.view.BaseView;
import com.strv.academyarchitecture.viewmodel.BaseViewModel;

import org.alfonz.mvvm.AlfonzBindingFragment;


public abstract class BaseFragment<T extends BaseView, R extends BaseViewModel<T>, B extends ViewDataBinding>
		extends AlfonzBindingFragment<T, R, B> implements BaseView
{
	@Override
	public void showToast(String message)
	{
		Toast.makeText(getActivity(), message, Toast.LENGTH_LONG).show();
	}
}
