package com.strv.academyarchitecture.view;

import com.strv.academyarchitecture.entity.MessageEntity;


public interface ListingView extends BaseView
{
	void onClick(MessageEntity message);
}
