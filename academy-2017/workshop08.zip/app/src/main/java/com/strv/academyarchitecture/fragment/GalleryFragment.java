package com.strv.academyarchitecture.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;

import com.strv.academyarchitecture.databinding.FragmentGalleryBinding;
import com.strv.academyarchitecture.entity.MessageEntity;
import com.strv.academyarchitecture.view.GalleryView;
import com.strv.academyarchitecture.viewmodel.GalleryViewModel;


public class GalleryFragment
		extends BaseFragment<GalleryView, GalleryViewModel, FragmentGalleryBinding>
		implements GalleryView
{
	public static String ARGUMENT_POSITION = "position";


	public static GalleryFragment newInstance(int position)
	{
		Bundle bundle = new Bundle();
		bundle.putInt(ARGUMENT_POSITION, position);

		GalleryFragment fragment = new GalleryFragment();
		fragment.setArguments(bundle);
		return fragment;
	}


	@Nullable
	@Override
	public Class<GalleryViewModel> getViewModelClass()
	{
		return GalleryViewModel.class;
	}


	@Override
	public FragmentGalleryBinding inflateBindingLayout(LayoutInflater inflater)
	{
		return FragmentGalleryBinding.inflate(inflater);
	}


	@Override
	public void onClick(MessageEntity message)
	{
		showToast(message.getMessage());
	}
}
