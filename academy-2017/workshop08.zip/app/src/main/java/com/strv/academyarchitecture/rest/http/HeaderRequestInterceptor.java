package com.strv.academyarchitecture.rest.http;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;


public class HeaderRequestInterceptor implements Interceptor
{
	@Override
	public Response intercept(Interceptor.Chain chain) throws IOException
	{
		Request.Builder builder = chain.request().newBuilder();
		builder.addHeader("Accept", "application/json");
		builder.addHeader("Accept-Charset", "utf-8");
		builder.addHeader("Content-Type", "application/json");
		Request request = builder.build();
		return chain.proceed(request);
	}
}
