package com.strv.academyarchitecture.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

import com.strv.academyarchitecture.fragment.GalleryFragment;
import com.strv.academyarchitecture.fragment.ListingFragment;

import eu.inloop.viewmodel.support.ViewModelStatePagerAdapter;


public class GalleryAdapter extends ViewModelStatePagerAdapter
{
	private static final int FRAGMENT_COUNT = 3;


	public GalleryAdapter(FragmentManager fragmentManager)
	{
		super(fragmentManager);
	}


	public static String getFragmentTag(int viewPagerId, int position)
	{
		return "android:switcher:" + viewPagerId + ":" + position;
	}


	@Override
	public int getCount()
	{
		return FRAGMENT_COUNT;
	}


	@Override
	public Fragment getItem(int position)
	{
		if(position == 0) return new ListingFragment();
		else return GalleryFragment.newInstance(position);
	}


	@Override
	public CharSequence getPageTitle(int position)
	{
		return "Fragment " + position;
	}


	public void refill()
	{
		notifyDataSetChanged();
	}
}
