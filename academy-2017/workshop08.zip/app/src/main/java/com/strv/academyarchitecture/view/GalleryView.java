package com.strv.academyarchitecture.view;

import com.strv.academyarchitecture.entity.MessageEntity;


public interface GalleryView extends BaseView
{
	void onClick(MessageEntity message);
}
