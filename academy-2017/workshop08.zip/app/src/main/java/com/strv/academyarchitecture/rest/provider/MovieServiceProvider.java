package com.strv.academyarchitecture.rest.provider;


import com.strv.academyarchitecture.entity.MovieEntity;
import com.strv.academyarchitecture.rest.RetrofitClient;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;


public class MovieServiceProvider
{
	public static final String MOVIE_CALL_TYPE = "movie";

	private static volatile MovieService sService;


	public interface MovieService
	{
		// movie/374720?api_key=bd7f681651d1b15fc0fe5a1892ae0151
		@GET("movie/{id}")
		Call<MovieEntity> movie(@Path("id") String id, @Query("api_key") String apiKey);
	}


	private MovieServiceProvider() {}


	public static MovieService getService()
	{
		if(sService == null)
		{
			synchronized(MovieServiceProvider.class)
			{
				if(sService == null)
				{
					sService = RetrofitClient.createService(MovieService.class);
				}
			}
		}
		return sService;
	}
}
