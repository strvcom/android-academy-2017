package com.strv.academyarchitecture.rest;

import com.strv.academyarchitecture.entity.ErrorEntity;

import org.alfonz.rest.HttpException;
import org.alfonz.rest.ResponseHandler;

import retrofit2.Response;


public class RestResponseHandler implements ResponseHandler
{
	@Override
	public boolean isSuccess(Response<?> response)
	{
		return response.isSuccessful();
	}


	@Override
	public String getErrorMessage(HttpException exception)
	{
		ErrorEntity error = (ErrorEntity) exception.error();
		return error.getStatusMessage();
	}


	@Override
	public String getFailMessage(Throwable throwable)
	{
		return throwable.getLocalizedMessage();
	}


	@Override
	public HttpException createHttpException(Response<?> response)
	{
		return new RestHttpException(response);
	}
}
