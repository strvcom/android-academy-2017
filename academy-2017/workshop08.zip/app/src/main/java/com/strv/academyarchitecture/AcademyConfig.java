package com.strv.academyarchitecture;


public class AcademyConfig
{
	public static final boolean LOGS = true;
	public static final boolean DEV_ENVIRONMENT = false;

	public static final String REST_BASE_URL_PROD = "https://api.themoviedb.org/3/";
	public static final String REST_BASE_URL_DEV = "https://api.themoviedb.org/3/";
	public static final String REST_BASE_URL = AcademyConfig.DEV_ENVIRONMENT ? AcademyConfig.REST_BASE_URL_DEV : AcademyConfig.REST_BASE_URL_PROD;

}
