package com.strv.academyarchitecture.fragment;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;

import com.strv.academyarchitecture.activity.GalleryActivity;
import com.strv.academyarchitecture.activity.ListingActivity;
import com.strv.academyarchitecture.databinding.FragmentMainBinding;
import com.strv.academyarchitecture.view.MainView;
import com.strv.academyarchitecture.viewmodel.MainViewModel;


public class MainFragment
		extends BaseFragment<MainView, MainViewModel, FragmentMainBinding>
		implements MainView
{
	@Nullable
	@Override
	public Class<MainViewModel> getViewModelClass()
	{
		return MainViewModel.class;
	}


	@Override
	public FragmentMainBinding inflateBindingLayout(LayoutInflater inflater)
	{
		return FragmentMainBinding.inflate(inflater);
	}


	@Override
	public void onClick()
	{
//		getViewModel().updateMessage("TIME: " + System.currentTimeMillis());
//		startListingActivity();
		startGalleryActivity();
	}


	private void startListingActivity()
	{
		Intent intent = ListingActivity.newIntent(getActivity());
		startActivity(intent);
	}


	private void startGalleryActivity()
	{
		Intent intent = GalleryActivity.newIntent(getActivity());
		startActivity(intent);
	}
}
