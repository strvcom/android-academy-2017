package com.strv.academyarchitecture.viewmodel;

import android.databinding.ObservableField;

import com.strv.academyarchitecture.AcademyApplication;
import com.strv.academyarchitecture.entity.MessageEntity;
import com.strv.academyarchitecture.entity.MovieEntity;
import com.strv.academyarchitecture.rest.RestHttpLogger;
import com.strv.academyarchitecture.rest.RestResponseHandler;
import com.strv.academyarchitecture.rest.provider.MovieServiceProvider;
import com.strv.academyarchitecture.view.MainView;

import org.alfonz.rest.HttpException;
import org.alfonz.rest.call.CallManager;
import org.alfonz.rest.call.Callback;
import org.alfonz.utility.NetworkUtility;
import org.alfonz.view.StatefulLayout;

import retrofit2.Call;
import retrofit2.Response;


public class MainViewModel extends BaseViewModel<MainView>
{
	public final ObservableField<Integer> state = new ObservableField<>();
	public final ObservableField<MessageEntity> message = new ObservableField<>();
	public final ObservableField<MovieEntity> movie = new ObservableField<>();

	private CallManager mCallManager = new CallManager(new RestResponseHandler(), new RestHttpLogger());


	@Override
	public void onStart()
	{
		super.onStart();
		if(message.get() == null) loadData();
	}


	@Override
	public void onDestroy()
	{
		super.onDestroy();

		// cancel async tasks
		if(mCallManager != null) mCallManager.cancelRunningCalls();
	}


	public void updateMessage(String text)
	{
		MessageEntity m = message.get();
		m.setMessage(text);
		message.notifyChange();
	}


	private void loadData()
	{
		// show progress
		state.set(StatefulLayout.PROGRESS);

		// load data from data provider...
		onLoadData(new MessageEntity("HELLO"));

		// load data from server
		sendMovie();
	}


	private void onLoadData(MessageEntity m)
	{
		// save data
		message.set(m);

		// show content
		if(message.get() != null)
		{
			state.set(StatefulLayout.CONTENT);
		}
		else
		{
			state.set(StatefulLayout.EMPTY);
		}
	}


	private void sendMovie()
	{
		if(NetworkUtility.isOnline(AcademyApplication.getContext()))
		{
			String callType = MovieServiceProvider.MOVIE_CALL_TYPE;
			if(!mCallManager.hasRunningCall(callType))
			{
				// show progress
				state.set(StatefulLayout.PROGRESS);

				// enqueue call
				Call<MovieEntity> call = MovieServiceProvider.getService().movie("374720", "bd7f681651d1b15fc0fe5a1892ae0151");
				MovieCallback callback = new MovieCallback(mCallManager);
				mCallManager.enqueueCall(call, callback, callType);
			}
		}
		else
		{
			// show offline
			state.set(StatefulLayout.OFFLINE);
		}
	}


	private void setState(ObservableField<MovieEntity> data)
	{
		if(data.get() != null)
		{
			state.set(StatefulLayout.CONTENT);
		}
		else
		{
			state.set(StatefulLayout.EMPTY);
		}
	}


	private class MovieCallback extends Callback<MovieEntity>
	{
		public MovieCallback(CallManager callManager)
		{
			super(callManager);
		}


		@Override
		public void onSuccess(Call<MovieEntity> call, Response<MovieEntity> response)
		{
			movie.set(response.body());
			setState(movie);
		}


		@Override
		public void onError(Call<MovieEntity> call, HttpException exception)
		{
			handleError(mCallManager.getHttpErrorMessage(exception));
			setState(movie);
		}


		@Override
		public void onFail(Call<MovieEntity> call, Throwable throwable)
		{
			handleError(mCallManager.getHttpErrorMessage(throwable));
			setState(movie);
		}
	}
}
