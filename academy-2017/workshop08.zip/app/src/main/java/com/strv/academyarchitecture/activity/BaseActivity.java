package com.strv.academyarchitecture.activity;

import org.alfonz.mvvm.AlfonzActivity;


public abstract class BaseActivity extends AlfonzActivity
{
	// add whatever you need...
}
