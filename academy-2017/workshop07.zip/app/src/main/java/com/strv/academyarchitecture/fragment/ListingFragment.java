package com.strv.academyarchitecture.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;

import com.strv.academyarchitecture.adapter.MultiListingAdapter;
import com.strv.academyarchitecture.databinding.FragmentListingBinding;
import com.strv.academyarchitecture.entity.MessageEntity;
import com.strv.academyarchitecture.view.ListingView;
import com.strv.academyarchitecture.viewmodel.ListingViewModel;


public class ListingFragment
		extends BaseFragment<ListingView, ListingViewModel, FragmentListingBinding>
		implements ListingView
{
	private MultiListingAdapter mAdapter;


	@Nullable
	@Override
	public Class<ListingViewModel> getViewModelClass()
	{
		return ListingViewModel.class;
	}


	@Override
	public FragmentListingBinding inflateBindingLayout(LayoutInflater inflater)
	{
		return FragmentListingBinding.inflate(inflater);
	}


	@Override
	public void onActivityCreated(Bundle savedInstanceState)
	{
		super.onActivityCreated(savedInstanceState);
		setupAdapter();
	}


	@Override
	public void onClick(MessageEntity message)
	{
		showToast(message.getMessage());
	}


	private void setupAdapter()
	{
		if(mAdapter == null)
		{
			mAdapter = new MultiListingAdapter(this, getViewModel());
			getBinding().fragmentListingRecycler.setAdapter(mAdapter);
		}
	}
}
