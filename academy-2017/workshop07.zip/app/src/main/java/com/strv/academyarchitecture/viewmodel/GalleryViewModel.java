package com.strv.academyarchitecture.viewmodel;

import android.databinding.ObservableField;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.strv.academyarchitecture.entity.MessageEntity;
import com.strv.academyarchitecture.fragment.GalleryFragment;
import com.strv.academyarchitecture.view.GalleryView;

import org.alfonz.view.StatefulLayout;


public class GalleryViewModel extends BaseViewModel<GalleryView>
{
	public final ObservableField<Integer> state = new ObservableField<>();
	public final ObservableField<MessageEntity> message = new ObservableField<>();

	private int mPosition;


	@Override
	public void onCreate(@Nullable Bundle arguments, @Nullable Bundle savedInstanceState)
	{
		handleArguments(arguments);
	}


	@Override
	public void onStart()
	{
		super.onStart();
		if(message.get() == null) loadData();
	}


	public void updateMessage(String text)
	{
		MessageEntity m = message.get();
		m.setMessage(text);
		message.notifyChange();
	}


	private void loadData()
	{
		// show progress
		state.set(StatefulLayout.PROGRESS);

		// load data from data provider...
		onLoadData(new MessageEntity("HELLO " + mPosition));
	}


	private void onLoadData(MessageEntity m)
	{
		// save data
		message.set(m);

		// show content
		if(message.get() != null)
		{
			state.set(StatefulLayout.CONTENT);
		}
		else
		{
			state.set(StatefulLayout.EMPTY);
		}
	}


	private void handleArguments(Bundle arguments)
	{
		if(arguments != null)
		{
			mPosition = arguments.getInt(GalleryFragment.ARGUMENT_POSITION);
		}
	}
}
