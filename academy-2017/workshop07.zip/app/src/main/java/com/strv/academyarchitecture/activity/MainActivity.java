package com.strv.academyarchitecture.activity;

import android.os.Bundle;

import com.strv.academyarchitecture.R;


public class MainActivity extends BaseActivity
{
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		setupActionBar(INDICATOR_NONE);
	}
}
