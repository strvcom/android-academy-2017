package com.strv.academyarchitecture.adapter;

import com.strv.academyarchitecture.R;
import com.strv.academyarchitecture.databinding.FragmentListingItemBinding;
import com.strv.academyarchitecture.view.ListingView;
import com.strv.academyarchitecture.viewmodel.ListingViewModel;

import org.alfonz.adapter.SimpleDataBoundRecyclerAdapter;


public class ListingAdapter extends SimpleDataBoundRecyclerAdapter<FragmentListingItemBinding>
{
	public ListingAdapter(ListingView view, ListingViewModel viewModel)
	{
		super(R.layout.fragment_listing_item, view, viewModel.messages);
	}
}
