package com.strv.academyarchitecture.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;

import com.strv.academyarchitecture.R;
import com.strv.academyarchitecture.adapter.GalleryAdapter;


public class GalleryActivity extends BaseActivity
{
	private GalleryAdapter mAdapter;


	public static Intent newIntent(Context context)
	{
		return new Intent(context, GalleryActivity.class);
	}


	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_gallery);
		setupActionBar(INDICATOR_BACK);
		setupAdapter();
	}


	private void setupAdapter()
	{
		if(mAdapter == null)
		{
			mAdapter = new GalleryAdapter(getSupportFragmentManager());
			ViewPager viewPager = (ViewPager) findViewById(R.id.activity_gallery_viewpager);
			viewPager.setAdapter(mAdapter);
		}
	}
}
