package com.strv.academyarchitecture.adapter;

import com.strv.academyarchitecture.R;
import com.strv.academyarchitecture.entity.MessageEntity;
import com.strv.academyarchitecture.view.ListingView;
import com.strv.academyarchitecture.viewmodel.ListingViewModel;

import org.alfonz.adapter.MultiDataBoundRecyclerAdapter;


public class MultiListingAdapter extends MultiDataBoundRecyclerAdapter
{
	public MultiListingAdapter(ListingView view, ListingViewModel viewModel)
	{
		super(view, viewModel.messages, viewModel.titles);
	}


	@Override
	public int getItemLayoutId(int position)
	{
		Object item = getItem(position);
		if(item instanceof String)
		{
			return R.layout.fragment_listing_item_title;
		}
		else if(item instanceof MessageEntity)
		{
			return R.layout.fragment_listing_item;
		}
		throw new IllegalArgumentException("Unknown item type " + item);
	}
}
